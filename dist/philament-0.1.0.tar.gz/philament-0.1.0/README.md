# Philament (Phil)

Phil is a Python script that allows for automated analysis of centriod objects

## Installation

In the Gregorio lab server, navigate to 1_Lab Resources, and open the folder labelled "Phil Program Files".
Then...
1.
